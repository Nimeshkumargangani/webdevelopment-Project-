<?php //echo $_SESSION['lang'];
						
						if(isset($_SESSION['lang']) && $_SESSION['lang'] == "en"){
						 ?>
<!-- Footer -->
<footer class="page-footer font-small blue">

  <!-- Copyright -->
  <div class="footer-copyright text-center py-2" style="background:black;color:white">DEVELOP BY :
    <a href="#" style="color:white"> XYZ</a>
  </div>
  <!-- Copyright -->

</footer>



<!-- Footer -->
<?php 	
						
						}
						
						else{ ?>
						<footer class="page-footer font-small blue">

  <!-- Copyright -->
  <div class="footer-copyright text-center py-2" style="background:black;color:white">ROZWIJAĆ SIĘ PRZEZ :
    <a href="#" style="color:white"> XYZ</a>
  </div>
  <!-- Copyright -->

</footer>
						<?php } ?>


<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/js/bootstrap.min.js" integrity="sha512-1/RvZTcCDEUjY/CypiMz+iqqtaoQfAITmNSJY17Myp4Ms5mdxPS5UV7iOfdZoxcGhzFbOm6sntTKJppjvuhg4g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/css/bootstrap-grid.rtl.min.css" integrity="sha512-TVEh7Wv2VL7denA2jjLclu/YHda8TiwmLZBhUqmJa+PVhIgbOs4mkx4nGQw+ok1f+3tf/NpbVDIuPKIHcSyEhw==" crossorigin="anonymous" referrerpolicy="no-referrer" />