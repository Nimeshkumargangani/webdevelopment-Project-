<!DOCTYPE html>
<html lang="en">

    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">   
   
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
 
     <!-- Site Metas -->
    <title>Tenant Tale </title>  
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- Colors CSS -->
    <link rel="stylesheet" href="css/colors.css">
    <!-- ALL VERSION CSS -->
    <link rel="stylesheet" href="css/versions.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <!-- Modernizer for Portfolio -->
    <script src="js/modernizer.js"></script>
</head>
<body class="realestate_version">
    <?php
        include 'header.php';
     ?>
   	
	<ul class='slideshow'>
		<li>
			<span>Summer</span>
		</li>
		<li>		
			<span>Fall</span>
		</li>
		<li>		
			<span>Winter</span>
		</li>
		<li>
			<span>Spring</span>
		</li>
	</ul>
	
    <div class="parallax first-section">
        <div class="container">
            <div class="row">
                <div class="col-md-6 wow slideInLeft hidden-xs hidden-sm">
                    
                </div>
				<div class="col-md-6 col-sm-12">
                    <div class="big-tagline clearfix">
					<?php if(isset($_SESSION['lang']) && $_SESSION['lang'] == "en"){ ?>
                        <h2>Rent Your Property with Tenant tale </h2>
                        <p class="lead">With Tenant Tale , you can promote your all property & real estate projects. </p>
                        <a data-scroll href="service.php" class="btn btn-light btn-radius grd1 btn-brd">Find Now</a>
					<?php } else { ?>
					<h2>Wynajmij swoją nieruchomość z opowieścią najemcy </h2>
                        <p class="lead">Dzięki Tenant Tale możesz promować wszystkie swoje projekty związane z nieruchomościami i nieruchomościami. </p>
                        <a data-scroll href="service.php" class="btn btn-light btn-radius grd1 btn-brd">Znajdź teraz</a>
					<?php } ?>
					
                    </div>
                </div>
            </div><!-- end row -->
        </div><!-- end container -->
    </div><!-- end section -->	
	
  <?php
    include 'footer.php';
 ?>
 
	
    <!-- ALL JS FILES -->
    <script src="js/all.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/custom.js"></script>
    <script src="js/portfolio.js"></script>


</body>
</html>
